import { Component } from '@angular/core';
import data from '../../../assets/contacts';
import { Contact } from 'src/app/model/contact';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent {

  contact : Contact[] = data;

}
